Link para a apresentação no Canva: [Canva](https://www.canva.com/design/DAGAbSzUkbs/RrXSd5QnbnBDPpoa8SPNiA/edit?utm_content=DAGAbSzUkbs&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton)

[![Análise de segurança do projeto](image.png)](https://www.canva.com/design/DAGAbSzUkbs/L8P_0m35HGJLUWhIwF_4zA/view)

<a href="https:&#x2F;&#x2F;www.canva.com&#x2F;design&#x2F;DAGAbSzUkbs&#x2F;L8P_0m35HGJLUWhIwF_4zA&#x2F;view?utm_content=DAGAbSzUkbs&amp;utm_campaign=designshare&amp;utm_medium=embeds&amp;utm_source=link" target="_blank" rel="noopener">Análise de segurança do prejeto</a> de Filipi Kikuchi

