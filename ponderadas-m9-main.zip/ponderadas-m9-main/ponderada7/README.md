# Ponderada 7 - Modificação do subscriber para ser um consumer do Kafka

## 1. Objetivo

Substituição do subscriber para ser um consumidor kafka

## 2. Enunciado

Atividade prática individual em sala de aula em que o aluno deve modificar a atividade anterior, fazendo com que o subscriber passe a consumir mensagens vindas do Kafka (configurado em cloudkarafka) e as armazene em um banco de dados Mongo.


## Lançando a aplicação

Para utilizar os módulos, clone o repositório, se ainda não o tiver feito e entre no diretório _ponderada7_:

```bash
    git clone https://github.com/HallZero/ponderadas-m9.git
    cd ponderadas-m9/ponderada5
```

### Metabase e MongoDB

Nessa aplicação, utilizamos tanto o Metabase quanto o MongoDB em containers. Para lançar os dois conjuntamente, vá para a o diretório _ponderada5_ e rode o comando:

```bash
docker compose up -d
```

> Nota: Para fazer a configuração da database no Metabase, no campo Host, coloque o nome do container "mongodb", a porta 27017 e Database name "teste_banco".

### Publisher:

1. Entre no diretório _publisher_:

   ```bash
   cd publisher
   ```

2. Rode o comando:

   ```bash
   go run .
   ```

### Subscriber:

1. Entre no diretório _package/kafka_:
   ```bash
   cd package/kafka
   ```
2. Rode o comando:
   ```bash
   go run .
   ```

### API:

🔥 Removação da API 🔥

### Modificações

Criação do consumer Kafka

```go
	err := godotenv.Load("../../.env")
	if err != nil {
		fmt.Printf("Error loading .env file: %s", err)
	}

	configMap := &kafka.ConfigMap{
		"bootstrap.servers":  os.Getenv("CONFLUENT_BOOTSTRAP_SERVER_SASL"),
		"security.protocol":  "SASL_SSL",
		"sasl.mechanisms":    "PLAIN",
		"sasl.username":      os.Getenv("CLUSTER_API_KEY"),
		"sasl.password":      os.Getenv("CLUSTER_API_SECRET"),
		"session.timeout.ms": 45000,
		"group.id":           "go-group-1",
		"auto.offset.reset":  "latest",
	}

	consumer, err := kafka.NewConsumer(configMap)

	if err != nil {
		log.Printf("Error creating kafka consumer: %v", err)
	}

	consumer.SubscribeTopics([]string{"nicola"}, nil)

	fmt.Println("Kafka consumer up and running!")

	run := true
	for run {

		e := consumer.Poll(1000)
		switch ev := e.(type) {
		case *kafka.Message:
			// application-specific processing
			fmt.Printf("Consumed event from topic %s: key = %-10s value = %s\n",
				*ev.TopicPartition.Topic, string(ev.Key), string(ev.Value))
			
			

		case kafka.Error:
			fmt.Fprintf(os.Stderr, "%% Error: %v\n", ev)
			run = false
		}
	}

	consumer.Close()
```

### Testes

Foram implementados testes para o Kafka e Mongo:

***Testes com Kafka***:
- Teste de conexão
- Teste de consumo da fila
```go
func TestKafkaConnection(t *testing.T) {
	// Set up test configuration
	config := setEnvironment(t)

	// Create a test Kafka consumer
	consumer, err := kafka.NewConsumer(&config)
	if err != nil {
		t.Fatalf("Error creating test consumer: %v", err)
	}
	defer func() {
		if err := consumer.Close(); err != nil {
			t.Fatalf("Error closing test consumer: %v", err)
		}
	}()

	// Try to fetch metadata to test connection
	if _, err := consumer.Subscription(); err != nil {
		t.Fatalf("Error fetching topics: %v", err)
	}
}
```



***Testes com Mongo***:
- Conexão com Mongo
- Teste de inserção no Mongo
- Teste de leitura no Mongo
```go
func testMongoConnection(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	client, err := mongo.Connect(context.TODO(), options.Client().ApplyURI("mongodb://localhost:27017/"))
	assert.NoError(t, err)
	defer func() {
		if err := client.Disconnect(ctx); err != nil {
			t.Fatalf("Error disconnecting from MongoDB: %v", err)
		}
	}()

	err = client.Ping(ctx, nil)
	assert.NoError(t, err)
}
``` 

## Vídeo de demonstração

[Modificação do subscriber para ser um consumer do Kafka](https://youtu.be/8zbs4RNuB_c)
