# prova2-m9
Prova 2 - Módulo 9

## Pastas
```bash
.
├── README.md
└── src
    ├── consumer
    │   └── consumer.go
    ├── docker-compose.yml
    ├── go.mod
    ├── go.sum
    ├── producer
    │   └── producer.go
    └── tests
        └── app_test.go
```

## Rodando o Kafka local
```bash
docker compose up -d
```

## Rodando o consumer e o producer

```bash
go mod tidy
```

```bash
cd consumer
go run consumer.go
```

```bash
cd producer
go run producer.go
```

## Rodando os Testes
```bash
cd tests
go test -v
```

## Vídeo de demonstração:
Está na pasta static ou no link a seguir: https://youtu.be/cCrbXTXe_w8


### Notas
Por algum motivo, não consigo enviar os dados do meu sensor normalmente. Ele manda um objeto vazio.
Quando rodo o arquivo de testes, um warning surge: 

```bash
testing: warning: no tests to run
PASS
ok      prova2/tests    0.003s
```
