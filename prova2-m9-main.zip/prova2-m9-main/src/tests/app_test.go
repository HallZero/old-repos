package main

import (
	"fmt"
	"testing"

	"github.com/confluentinc/confluent-kafka-go/kafka"
)

func applicationTest(t *testing.T) {

	t.Run("Sending data to Kafka topic without modification", func(t *testing.T) {
		prod := createProducer()

		fmt.Println(prod)

		defer prod.Close()

		topic := "qualidadeAr"

		message := "Testing sending message"

		fmt.Println(message)

		prod.Produce(&kafka.Message{
			TopicPartition: kafka.TopicPartition{Topic: &topic, Partition: kafka.PartitionAny},
			Value:          []byte(message),
		}, nil)

		prod.Flush(15 * 1000)

		consumer, err := kafka.NewConsumer(&kafka.ConfigMap{
			"bootstrap.servers": "localhost:29092",
			"group.id":          "go-consumer-group",
			"auto.offset.reset": "earliest",
		})

		if err != nil {
			t.Error(err)
		}

		defer consumer.Close()

		consumer.SubscribeTopics([]string{topic}, nil)

		msg, err := consumer.ReadMessage(-1)
		if string(msg.Value) != message {
			t.Errorf("Error! Message received not equal to message sent!")
		} else {
			t.Logf("Message received with success!")
		}

	})

	t.Run("Check all persist data", func(t *testing.T) {

		// Consumindo a fila do Kafka com um consumer

		topic := "qualidadeAr"

		consumer, err := kafka.NewConsumer(&kafka.ConfigMap{
			"bootstrap.servers": "localhost:29092",
			"group.id":          "go-consumer-group",
			"auto.offset.reset": "earliest",
		})

		if err != nil {
			panic(err)
		}

		defer consumer.Close()

		consumer.SubscribeTopics([]string{topic}, nil)

		for {
			msg, err := consumer.ReadMessage(-1)
			if err == nil {
				fmt.Printf("Received message: %s\n", string(msg.Value))
			} else {
				fmt.Printf("Consumer error: %v (%v)\n", err, msg)
				break
			}
		}
	})
}

func createProducer() *kafka.Producer {
	producer, err := kafka.NewProducer(&kafka.ConfigMap{
		"bootstrap.servers": "localhost:29092",
		"client.id":         "go-producer",
	})

	if err != nil {
		panic(err)
	}

	return producer
}
