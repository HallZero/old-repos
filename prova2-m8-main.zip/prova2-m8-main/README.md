# prova2-m8

Utilizando o bark, criei uma interface simples de TTS em que o usuário digita o texto e o modelo converte a informação contida em texto.

Link para o colab: https://colab.research.google.com/drive/1YHFfGQ-UzCuDnVTBXqiZFbHTV-w9iJz6?usp=sharing

