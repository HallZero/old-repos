# prova2
Prova 2

No arquivo faces.py, é proposta a utilização de um modelo pré-treinado do roboflow.
O código utiliza o vídeo disponível em assets, faz as predições necessárias e desenha um retângulo nas coordenadas de onde supostamente o rosto está localizado. 
Ao final, um vídeo out.avi é gerado.