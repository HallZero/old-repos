let myFriends = []

